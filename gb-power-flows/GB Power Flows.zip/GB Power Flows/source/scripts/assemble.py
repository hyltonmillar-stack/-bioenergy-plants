import json,sys
S=sys.argv[1];content=sys.argv[2];out=sys.argv[3]
t=open(S+"/template.html").read()
data=json.load(open(S+"/sitedata.json"))
mix=json.load(open(S+"/dl/mix.json"))[-96:]
t=t.replace("const DATA = /*DATA*/null;","const DATA = "+json.dumps(data,separators=(",",":"))+";")
t=t.replace("const CONTENT = /*CONTENT*/null;","const LIVEFB="+json.dumps(mix,separators=(",",":"))+";\n"+open(S+"/geo.js").read()+"\n"+open(content).read())
t=t.replace("/*APP*/",open(S+"/app.js").read())
open(out,"w").write(t);print(len(t))
