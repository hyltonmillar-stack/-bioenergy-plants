import json,collections as C,sys
D=sys.argv[1]
out={}
# annual mix
m=json.load(open(D+"/mix.json"))
keys=["GAS","COAL","NUCLEAR","WIND","WIND_EMB","HYDRO","IMPORTS","BIOMASS","OTHER","SOLAR","STORAGE","GENERATION"]
agg=C.defaultdict(lambda:C.defaultdict(float));n=C.Counter();ci=C.defaultdict(float)
for r in m:
    y=r["DATETIME"][:4];n[y]+=1;ci[y]+=float(r["CARBON_INTENSITY"] or 0)
    for k in keys: agg[y][k]+=float(r[k] or 0)/2e6
out["annual"]={y:{**{k:round(v,2) for k,v in agg[y].items()},"CI":round(ci[y]/n[y]),"n":n[y]} for y in sorted(agg)}
for y in sorted(agg): print(y,n[y],{k:round(v,1) for k,v in agg[y].items()},round(ci[y]/n[y]))
# monthly 2024-2026
mm=C.defaultdict(lambda:C.defaultdict(float));mn=C.Counter()
for r in m:
    if r["DATETIME"]>="2024":
        k=r["DATETIME"][:7];mn[k]+=1
        for f in keys: mm[k][f]+=float(r[f] or 0)/2e6
out["monthly"]={k:{f:round(v,3) for f,v in mm[k].items()} for k in sorted(mm)}
# peaks / records
best=max(m,key=lambda r:float(r["WIND"] or 0)+float(r["WIND_EMB"] or 0))
print("max wind",best["DATETIME"],best["WIND"],best["WIND_EMB"])
lowci=min((r for r in m if r["DATETIME"]>="2025"),key=lambda r:float(r["CARBON_INTENSITY"]))
print("min CI 2025+",lowci["DATETIME"],lowci["CARBON_INTENSITY"])
out["records"]={"maxwind":[best["DATETIME"],float(best["WIND"])+float(best["WIND_EMB"])],"minci":[lowci["DATETIME"],lowci["CARBON_INTENSITY"]]}
# demand/flows
ic=["IFA_FLOW","IFA2_FLOW","BRITNED_FLOW","MOYLE_FLOW","EAST_WEST_FLOW","NEMO_FLOW","NSL_FLOW","ELECLINK_FLOW","VIKING_FLOW","GREENLINK_FLOW"]
flows={}
for y in ["2024","2025","2026"]:
    d=json.load(open(f"{D}/d{y}.json"))
    if y=="2026": d=[r for r in d if r.get("FORECAST_ACTUAL_INDICATOR")=="A"]
    f={}
    for k in ic:
        v=[float(r[k] or 0) for r in d]
        f[k]={"imp":round(sum(x for x in v if x>0)/2e6,2),"exp":round(-sum(x for x in v if x<0)/2e6,2),"net":round(sum(v)/2e6,2),"maxImp":max(v),"maxExp":min(v)}
    st=[float(r["SCOTTISH_TRANSFER"] or 0) for r in d]
    nd=[float(r["ND"] or 0) for r in d]
    f["SCOT"]={"twh":round(sum(st)/2e6,2),"avg":round(sum(st)/len(st)),"max":max(st),"min":min(st),"p_gt5":round(sum(1 for x in st if x>5000)/len(st)*100,1)}
    f["ND"]={"twh":round(sum(nd)/2e6,1),"peak":max(nd),"min":min(nd),"peakdate":max(d,key=lambda r:float(r["ND"]))["SETTLEMENT_DATE"]}
    f["EMB"]={"wind":round(sum(float(r["EMBEDDED_WIND_GENERATION"] or 0) for r in d)/2e6,1),"solar":round(sum(float(r["EMBEDDED_SOLAR_GENERATION"] or 0) for r in d)/2e6,1),"solarcap":d[-1]["EMBEDDED_SOLAR_CAPACITY"],"windcap":d[-1]["EMBEDDED_WIND_CAPACITY"]}
    f["period"]=[d[0]["SETTLEMENT_DATE"],d[-1]["SETTLEMENT_DATE"],len(d)]
    # avg daily profile of scot transfer by month
    flows[y]=f;print(y,json.dumps(f)[:1500])
out["flows"]=flows
# daily series 2025-2026 of scot transfer and net imports for chart
ser=C.defaultdict(lambda:[0,0,0])
for y in ["2025","2026"]:
    for r in json.load(open(f"{D}/d{y}.json")):
        if y=="2026" and r.get("FORECAST_ACTUAL_INDICATOR")!="A":continue
        s=ser[r["SETTLEMENT_DATE"][:7]];s[0]+=float(r["SCOTTISH_TRANSFER"] or 0);s[1]+=sum(float(r[k] or 0) for k in ic);s[2]+=1
out["monthflows"]={k:[round(v[0]/v[2]),round(v[1]/v[2])] for k,v in sorted(ser.items())}
json.dump(out,open(D+"/../agg.json","w"))
