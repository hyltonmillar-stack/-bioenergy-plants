import json,collections as C,sys
D=sys.argv[1];A=json.load(open(D+"/../agg.json"))
tec=json.load(open(D+"/tec.json"))['result']['records']
icr=json.load(open(D+"/ic.json"))['result']['records']
def cat(p,name=""):
    if name.startswith("Pembroke Power"): return "Gas & thermal"
    p=p or ""
    for k,v in [("Nuclear","Nuclear"),("Wind Offshore","Offshore wind"),("CCGT","Gas & thermal"),("OCGT","Gas & thermal"),("Gas Recip","Gas & thermal"),("CHP","Gas & thermal"),("Oil","Gas & thermal"),("Thermal","Gas & thermal"),("Biomass","Biomass & waste"),("Waste","Biomass & waste"),("Pump Storage","Pumped storage"),("Wind Onshore","Onshore wind"),("PV","Solar"),("Hydrogen","Other"),("Hydro","Hydro"),("Energy Storage","Battery storage")]:
        if k in p: return v
    return "Other"
cm={}
for x in tec:
    if (x['MW Connected'] or 0)>0:
        k=(x['Project Name'],x['Connection Site'])
        if k not in cm or x['MW Connected']>cm[k]['MW Connected']: cm[k]=x
con=list(cm.values())
conn=C.defaultdict(lambda:C.defaultdict(float))
for x in con: conn[x['HOST TO']][cat(x['Plant Type'],x['Project Name'])]+=x['MW Connected']
pipe=[x for x in tec if x['Project Status']!='Built' and (x['MW Increase / Decrease'] or 0)>0]
pc=C.defaultdict(lambda:C.defaultdict(float));py=C.defaultdict(lambda:C.defaultdict(float));pto=C.defaultdict(float);pg=C.defaultdict(float)
for x in pipe:
    c=cat(x['Plant Type'],x['Project Name']);mw=x['MW Increase / Decrease']
    pc[c][x['Project Status']]+=mw
    y=(x['MW Effective From'] or '')[:4]
    y = "≤2026" if y and y<="2026" else y
    py[y][c]+=mw;pto[x['HOST TO']]+=mw;pg[str(x['Gate'] or 'Not yet classified')]+=mw
uc=sorted([x for x in pipe if x['Project Status']=='Under Construction/Commissioning'],key=lambda x:-x['MW Increase / Decrease'])[:15]
def short(x): return {"name":x['Project Name'],"owner":x['Customer Name'],"site":x['Connection Site'],"to":x['HOST TO'],"type":cat(x['Plant Type'],x['Project Name']),"mw":round(x['MW Increase / Decrease'] or x['MW Connected']),"date":x['MW Effective From'],"status":x['Project Status']}
top=[{"name":x['Project Name'],"owner":x['Customer Name'],"site":x['Connection Site'],"to":x['HOST TO'],"type":cat(x['Plant Type'],x['Project Name']),"mw":round(x['MW Connected'])} for x in sorted(con,key=lambda x:-x['MW Connected'])[:40]]
ics=[{"name":x['Project Name'],"owner":x['Customer Name'],"site":x['Connection Site'],"to":x['HOST TO'],"imp":x['MW Import - Total'],"exp":x['MW Export - Total'],"date":x['MW Effective From'],"status":x['Project Status']} for x in icr]
def grp(pat):
    s=[x for x in tec if any(p in (x['Customer Name'] or '').upper() for p in pat)]
    return {"conn":round(sum(x['MW Connected'] or 0 for x in s)),"pipe":round(sum(x['MW Increase / Decrease'] or 0 for x in s if x['Project Status']!='Built')),"n":len(s),
      "top":[short(x) for x in sorted(s,key=lambda x:-max(x['MW Connected'] or 0,x['MW Increase / Decrease'] or 0))[:10]]}
out={"annual":A["annual"],"monthly":A["monthly"],"flows":A["flows"],"monthflows":A["monthflows"],"records":A["records"],
 "tec":{"asof":"2026-10-16","conn":{t:{k:round(v) for k,v in d.items()} for t,d in conn.items()},"pipeCat":{c:{k:round(v) for k,v in d.items()} for c,d in pc.items()},
 "pipeYear":{y:{k:round(v) for k,v in d.items()} for y,d in sorted(py.items())},"pipeTO":{k:round(v) for k,v in pto.items()},"pipeGate":{k:round(v) for k,v in pg.items()},
 "pipeTotal":round(sum(x['MW Increase / Decrease'] for x in pipe)),"pipeN":len(pipe),"connTotal":round(sum(x['MW Connected'] for x in con)),"connN":len(con),"uc":[short(x) for x in uc],"top":top},
 "ic":ics,"sse":grp(["SSE "]),"spr":grp(["SCOTTISHPOWER"])}
json.dump(out,open(D+"/../sitedata.json","w"),separators=(",",":"))
print(len(json.dumps(out)),out["tec"]["pipeGate"],out["sse"]["conn"],out["spr"]["conn"])
