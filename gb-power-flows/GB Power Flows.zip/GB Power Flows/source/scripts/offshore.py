import json,sys
S=sys.argv[1]
r=json.load(open(S+'/dl/tec.json'))['result']['records']
o=[x for x in r if (x['MW Connected'] or 0)>0 and 'Wind Offshore' in (x['Plant Type'] or '')]
cm={}
for x in o:
  k=(x['Project Name'],x['Connection Site'])
  if k not in cm or x['MW Connected']>cm[k]['MW Connected']: cm[k]=x
G={'Hornsea Power Station 1A':'Hornsea One','Hornsea Power Station 1B':'Hornsea One','Hornsea Power Station 1C':'Hornsea One',
 'Hornsea Power Station 2A':'Hornsea Two','Hornsea Power Station 2B':'Hornsea Two','Hornsea Power Station 2C':'Hornsea Two',
 'Walney I Offshore Wind Farm':'Walney','Walney II Offshore Wind Farm':'Walney','Walney 3 Offshore Wind Farm':'Walney Extension','Walney 4 Offshore Wind Farm':'Walney Extension',
 'Robin Rigg West Offshore Wind Farm':'Robin Rigg','Robin Rigg East Offshore Wind Farm':'Robin Rigg',
 'Gunfleet Sands Offshore Wind Farm':'Gunfleet Sands','Gunfleet Sands II Offshore Wind Farm':'Gunfleet Sands',
 'Dogger Bank Project A':'Dogger Bank A','Dogger Bank Project 4 (Dogger Bank B)':'Dogger Bank B'}
def clean(n): 
  n=G.get(n,n)
  for s in [' Offshore Wind Farm',' Offshore Windfarm',' Wind Farm',' 1']: n=n.replace(s,'') if n.endswith(s) else n
  return n
GEO={'Sofia':[54.97,1.90],'Dogger Bank A':[54.78,1.75],'Dogger Bank B':[55.05,2.25],'Seagreen':[56.60,-1.75],'Moray East':[58.19,-2.72],'Moray West':[58.08,-3.10],
 'Triton Knoll':[53.50,0.80],'East Anglia One':[52.23,2.50],'London Array':[51.63,1.50],'Beatrice':[58.25,-3.00],'Gwynt Y Mor':[53.45,-3.60],'Race Bank':[53.27,0.84],
 'Greater Gabbard':[51.93,1.93],'Neart Na Gaoithe':[56.27,-2.30],'Hornsea Two':[53.97,1.95],'Hornsea One':[53.85,1.75],'Dudgeon':[53.27,1.38],'Rampion':[50.67,-0.27],
 'West of Duddon Sands':[53.98,-3.47],'Galloper':[51.87,2.05],'Walney Extension':[54.09,-3.72],'Walney':[54.04,-3.52],'Sheringham Shoal':[53.13,1.15],'Thanet':[51.43,1.63],
 'Lincs':[53.19,0.48],'Burbo Bank Extension':[53.53,-3.30],'Burbo Bank':[53.48,-3.18],'Humber Gateway':[53.64,0.29],'Westermost Rough':[53.81,0.15],'Ormonde':[54.10,-3.40],
 'Gunfleet Sands':[51.73,1.22],'Aberdeen':[57.22,-1.98],'Robin Rigg':[54.75,-3.71],'Barrow':[53.99,-3.29],'Kincardine':[57.00,-1.86]}
farms={}
for x in cm.values():
  n=clean(x['Project Name']);f=farms.setdefault(n,{'name':n,'mw':0,'owner':x['Customer Name'],'to':x['HOST TO'],'phases':0,'type':'Offshore wind'})
  f['mw']+=x['MW Connected'];f['phases']+=1
L=sorted(farms.values(),key=lambda f:-f['mw'])
miss=[f['name'] for f in L if f['name'] not in GEO];print('missing geo',miss)
for f in L: f['mw']=round(f['mw']);f['geo']=GEO.get(f['name'])
d=json.load(open(S+'/sitedata.json'));d['offshore']=L;json.dump(d,open(S+'/sitedata.json','w'),separators=(',',':'))
print(len(L),sum(f['mw'] for f in L))
