import json,urllib.request,urllib.parse,sys,ssl
B="https://api.neso.energy/api/3/action/datastore_search?"
def pull(rid,fields,out):
    rows=[];off=0
    while True:
        u=B+urllib.parse.urlencode({"resource_id":rid,"fields":",".join(["_id"]+fields),"limit":32000,"offset":off,"sort":"_id asc"})
        d=json.load(urllib.request.urlopen(u,timeout=180))["result"]
        rows+=d["records"];off+=32000
        print(out,len(rows),d["total"],file=sys.stderr)
        if off>=d["total"]:break
    json.dump(rows,open(out,"w"))
ic=["IFA_FLOW","IFA2_FLOW","BRITNED_FLOW","MOYLE_FLOW","EAST_WEST_FLOW","NEMO_FLOW","NSL_FLOW","ELECLINK_FLOW","VIKING_FLOW","GREENLINK_FLOW"]
dem=["SETTLEMENT_DATE","SETTLEMENT_PERIOD","ND","TSD","ENGLAND_WALES_DEMAND","EMBEDDED_WIND_GENERATION","EMBEDDED_SOLAR_GENERATION","EMBEDDED_SOLAR_CAPACITY","EMBEDDED_WIND_CAPACITY","PUMP_STORAGE_PUMPING","SCOTTISH_TRANSFER"]
pull("f6d02c0f-957b-48cb-82ee-09003f2ba759",dem+ic,sys.argv[1]+"/d2024.json")
pull("b2bde559-3455-4021-b179-dfe60c0337b0",dem+ic,sys.argv[1]+"/d2025.json")
pull("8a4a771c-3929-4e56-93ad-cdf13219dea5",dem+ic+["FORECAST_ACTUAL_INDICATOR"],sys.argv[1]+"/d2026.json")
pull("f93d1835-75bc-43e5-84ad-12472b180a98",["DATETIME","GAS","COAL","NUCLEAR","WIND","WIND_EMB","HYDRO","IMPORTS","BIOMASS","OTHER","SOLAR","STORAGE","GENERATION","CARBON_INTENSITY"],sys.argv[1]+"/mix.json")
