import json,collections as C,sys,re
D=sys.argv[1]
r=json.load(open(D+"/tec.json"))['result']['records']
def cat(p):
    p=p or ""
    if "Nuclear" in p: return "Nuclear"
    if "Wind Offshore" in p: return "Offshore wind"
    if "CCGT" in p or "OCGT" in p or "Gas Recip" in p or "CHP" in p or "Oil" in p or "Thermal" in p: return "Gas & thermal"
    if "Biomass" in p or "Waste" in p: return "Biomass & waste"
    if "Pump Storage" in p: return "Pumped storage"
    if "Wind Onshore" in p: return "Onshore wind"
    if "PV" in p: return "Solar (incl. hybrid)"
    if "Hydrogen" in p: return "Hydrogen"
    if "Hydro" in p: return "Hydro"
    if "Energy Storage" in p: return "Battery storage"
    if "Demand" in p: return "Demand"
    return "Other"
# check stage duplicates: projects with multiple stages; use per-row MW Connected for built; pipeline = MW Increase
built=[x for x in r if x['Project Status']=='Built']
print('built rows',len(built),'conn MW',sum(x['MW Connected'] or 0 for x in built))
con=[x for x in r if (x['MW Connected'] or 0)>0]
# dedupe connected by project name+site taking max MW Connected
cm={}
for x in con:
    k=(x['Project Name'],x['Connection Site'])
    if k not in cm or x['MW Connected']>cm[k]['MW Connected']: cm[k]=x
con=list(cm.values());print('dedup connected',len(con),round(sum(x['MW Connected'] for x in con)))
bycat=C.defaultdict(float);byto=C.defaultdict(lambda:C.defaultdict(float))
for x in con:
    c=cat(x['Plant Type']);bycat[c]+=x['MW Connected'];byto[x['HOST TO']][c]+=x['MW Connected']
print({k:round(v) for k,v in sorted(bycat.items(),key=lambda t:-t[1])})
for t in byto: print(t,round(sum(byto[t].values())),{k:round(v) for k,v in byto[t].items()})
top=sorted(con,key=lambda x:-x['MW Connected'])[:60]
for x in top: print(round(x['MW Connected']),'|',x['Project Name'],'|',x['Customer Name'],'|',x['Connection Site'],'|',x['HOST TO'],'|',cat(x['Plant Type']))
# pipeline: not built, MW Increase>0
pipe=[x for x in r if x['Project Status']!='Built' and (x['MW Increase / Decrease'] or 0)>0]
pc=C.defaultdict(lambda:C.defaultdict(float))
for x in pipe: pc[cat(x['Plant Type'])][x['Project Status']]+=x['MW Increase / Decrease']
print('pipeline GW',round(sum(x['MW Increase / Decrease'] for x in pipe)/1000,1),len(pipe))
for k,v in sorted(pc.items(),key=lambda t:-sum(t[1].values())): print(k,round(sum(v.values())),{a:round(b) for a,b in v.items()})
py=C.defaultdict(float)
for x in pipe: py[(x['MW Effective From'] or '????')[:4]]+=x['MW Increase / Decrease']
print({k:round(v/1000,1) for k,v in sorted(py.items())})
pto=C.defaultdict(float)
for x in pipe: pto[x['HOST TO']]+=x['MW Increase / Decrease']
print({k:round(v/1000,1) for k,v in pto.items()})
uc=sorted([x for x in pipe if x['Project Status']=='Under Construction/Commissioning'],key=lambda x:-x['MW Increase / Decrease'])
for x in uc[:30]: print('UC',round(x['MW Increase / Decrease']),x['Project Name'],'|',x['Customer Name'],'|',x['Connection Site'],x['HOST TO'],cat(x['Plant Type']),x['MW Effective From'])
gate=C.Counter((x['Gate'],x['Project Status']) for x in pipe);print(gate)
for pat in ['SSE','SCOTTISHPOWER','SCOTTISH POWER','IBERDROLA','EAST ANGLIA','SEAGREEN','BEATRICE','DOGGER','DRAX','EDF','RWE','ORSTED']:
    s=[x for x in r if pat in (x['Customer Name'] or '').upper() or pat in (x['Project Name'] or '').upper()]
    print('##',pat,len(s),'conn',round(sum(x['MW Connected'] or 0 for x in s)),'pipe',round(sum(x['MW Increase / Decrease'] or 0 for x in s if x['Project Status']!='Built')))
    for x in sorted(s,key=lambda x:-max(x['MW Connected'] or 0,x['MW Increase / Decrease'] or 0))[:12]: print('   ',x['Project Name'],'|',x['Customer Name'],'|',x['Project Status'],x['MW Connected'],x['MW Increase / Decrease'],x['MW Effective From'],cat(x['Plant Type']),x['HOST TO'])
