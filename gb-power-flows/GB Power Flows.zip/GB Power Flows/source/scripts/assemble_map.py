import json,sys
S=sys.argv[1];t=open(S+"/map_template.html").read()
t=t.replace("const DATA=/*DATA*/null;","const DATA="+open(S+"/sitedata.json").read()+";").replace("/*GEO*/",open(S+"/geo.js").read())
open(sys.argv[2],"w").write(t);print(len(t))
