const fmtN=(v,d=0)=>Number(v).toLocaleString('en-GB',{maximumFractionDigits:d,minimumFractionDigits:d});
const CONTENT=Object.assign({},GEO,{liveFallback:LIVEFB,
networks:`
<p class="intro">Great Britain has one system operator and three onshore transmission owners. NESO (the National Energy System Operator, publicly owned since 1 October 2024) balances the system in real time, runs the connections queue and plans the network. National Grid Electricity Transmission (NGET) owns the network in England and Wales. In Scotland, SP Transmission (ScottishPower) owns the south and SSEN Transmission (SSE) owns the north.</p>
<div class="grid3">
 <div class="card"><h3>The B6 boundary: Scotland to England</h3>
  <ul class="factlist">
   <li>Current capability is <strong>6.7 GW</strong>. The limit is a thermal constraint on the Harker–Moffat 400 kV circuit (NESO ETYS).</li>
   <li>In 2025 the half-hourly transfer reached 6,586 MW and averaged 2,114 MW. When Scottish wind output exceeds what the boundary can carry, NESO pays generators to reduce output.</li>
   <li>Existing paths are the onshore AC circuits on the east and west coasts, plus the <strong>Western Link</strong> HVDC from Hunterston to Flintshire Bridge (about 2.2 GW, operating since 2019, SPT/NGET).</li>
  </ul></div>
 <div class="card"><h3>Eastern Green Links (under construction)</h3>
  <ul class="factlist">
   <li><strong>EGL1:</strong> 2 GW HVDC from Torness (East Lothian) to Hawthorn Pit (County Durham), about 196 km. A joint venture of SP Energy Networks and NGET, costing about £2.5bn. Construction began February 2025; target 2029.</li>
   <li><strong>EGL2:</strong> 2 GW, 525 kV HVDC from Peterhead to Drax (North Yorkshire), about 436 km subsea. A joint venture of SSEN Transmission and NGET, costing £4.3bn. Construction began September 2024; target 2029. As of August 2026 the first converter building frame at Peterhead was complete.</li>
   <li>Together the two links add 4 GW of north–south capacity.</li>
  </ul></div>
 <div class="card"><h3>Cost of constraints</h3>
  <ul class="factlist">
   <li>NESO balancing costs were <strong>£3,093m in 2025-26</strong>, against a benchmark of £2,936m (excluding Winter Contingency costs).</li>
   <li>In 2024-25 they were £2.7bn, of which thermal constraints were £1.7bn. Thermal constraints are about 60% of balancing costs (NESO, July 2026).</li>
  </ul></div>
</div>
<div class="grid2">
 <div class="card"><h3>Investment plans, RIIO-T3 (April 2026 to March 2031)</h3>
  <table><thead><tr><th>Owner</th><th>Area</th><th>Plan</th></tr></thead><tbody>
   <tr><td>SSEN Transmission (SSE)</td><td>North of Scotland</td><td>About £22.3bn total expenditure, of which about £16bn on strategic (ASTI/LOTI) projects, with a further potential £9.4bn. It accepted Ofgem's Final Determination in March 2026. "Pathway to 2030" is over £20bn.</td></tr>
   <tr><td>SP Transmission (ScottishPower)</td><td>Central and southern Scotland</td><td>More than £11.6bn nominal submitted. At draft determination (July 2025) Ofgem endorsed 95% of it. EGL1, EGL4 and Western Link 2 make up about a third.</td></tr>
   <tr><td>NGET (National Grid)</td><td>England and Wales</td><td>The "Great Grid Upgrade" programme of onshore reinforcements and HVDC links.</td></tr>
  </tbody></table>
  <p class="note">NESO's Clean Power 2030 advice put network investment at up to £60bn to 2030. That covers nearly 1,000 km of new onshore and over 4,500 km of offshore network.</p></div>
 <div class="card"><h3>Security of supply</h3>
  <ul class="factlist">
   <li>NESO's <strong>Winter Outlook 2026/27</strong> Early View (June 2026) gives a base-case de-rated margin of <strong>5.5 GW</strong>, which is 8.8% of Average Cold Spell peak demand. Loss of load expectation is below 0.1 hours a year, against a 3-hour standard. The full Outlook had not been published at the time of compilation.</li>
   <li>The T-1 Capacity Market auction for 2026/27 secured 7.2 GW.</li>
   <li>DUKES 2026 gives UK de-rated capacity of 74.5 GW (renewables 27.7 GW) and winter peak demand of 51.5 GW. NESO's transmission-level national demand peaked at 47,382 MW on 5 January 2026.</li>
  </ul></div>
</div>
<div class="src">Sources: NESO ETYS Scottish boundaries; NESO BP3 End-Scheme Reported Metrics Annex (May 2026); NESO Winter Outlook Early View (June 2026); NESO Clean Power 2030 advice (Nov 2024); EGL1 project updates (SPEN/NGET); SSEN Transmission EGL2 progress note (Aug 2026) and RIIO-T3 statement (Mar 2026); SP Energy Networks RIIO-T3 documents.</div>`,
utilities:D=>{
 const tec=(n)=>{const t=D.tec.top.find(x=>x.name===n);return t?fmtN(t.mw):'—';};
 return `
<p class="intro">SSE and ScottishPower are the two vertically integrated groups based in Scotland. Each owns a transmission network (SHET and SPT) and a large renewable generation fleet. The figures below come from each company's disclosures and from the TEC register.</p>
<div class="grid2">
 <div class="card"><h3>SSE plc</h3>
  <p class="note">Installed capacity at 31 March 2026, SSE share of joint ventures (FY26 preliminary results, 28 May 2026).</p>
  <table><tbody>
   <tr><td>Offshore wind</td><td class="n">1,014 MW</td></tr><tr><td>Onshore wind</td><td class="n">2,570 MW</td></tr>
   <tr><td>Conventional hydro</td><td class="n">1,164 MW</td></tr><tr><td>Pumped storage (Foyers)</td><td class="n">300 MW</td></tr>
   <tr><td>Batteries and solar</td><td class="n">231 MW</td></tr><tr><td><strong>Renewables total</strong></td><td class="n"><strong>5,279 MW</strong></td></tr>
   <tr><td>Gas thermal</td><td class="n">6,210 MW</td></tr><tr><td>Energy from waste and biomass</td><td class="n">43 MW</td></tr>
  </tbody></table>
  <h3 style="margin-top:14px">Key assets (gross TEC, MW)</h3>
  <ul class="factlist">
   <li><strong>Dogger Bank A and B</strong>: 1,200 MW each. SSE 40%, Equinor 40%, Vårgrønn 20%. A completed turbine installation in February 2026; B delivered first power in March 2026. Dogger Bank C (1,200 MW) completed its foundations in November 2025.</li>
   <li><strong>Seagreen</strong>: ${tec('Seagreen 1 Offshore Wind Farm')} MW, SSE 49%, operating. Seagreen 1A (500 MW) is under construction on the register.</li>
   <li><strong>Beatrice</strong>: ${tec('Beatrice Wind Farm')} MW, SSE 40%. <strong>Viking</strong> (Shetland): 443 MW, completed August 2024.</li>
   <li><strong>Peterhead CCGT</strong>: ${tec('Peterhead')} MW TEC. <strong>Keadby 2</strong>: ${tec('Keadby II')} MW TEC. Peterhead carbon capture (910 MW on the register) has no investment decision yet.</li>
   <li><strong>Berwick Bank</strong>: consented July 2025 for up to 4.1 GW. Berwick Bank B won 1.4 GW in CfD Allocation Round 7 (January 2026); final investment decision expected 2027.</li>
   <li><strong>Coire Glas</strong>: 1.4 GW pumped storage, at Ofgem cap-and-floor project assessment.</li>
   <li>Group investment plan: £33bn over five years to 2029/30, of which about £22bn is SSEN Transmission.</li>
  </ul></div>
 <div class="card"><h3>ScottishPower (Iberdrola)</h3>
  <p class="note">ScottishPower Renewables holds ${fmtN(D.spr.conn/1000,2)} GW of connected TEC under its own name on the register, almost all onshore wind in SPT's area. Offshore projects are held by project companies.</p>
  <h3 style="margin-top:6px">Key assets</h3>
  <ul class="factlist">
   <li><strong>East Anglia ONE</strong>: ${tec('East Anglia One')} MW TEC, operating.</li>
   <li><strong>East Anglia THREE</strong>: 1,400 MW, 95 turbines, about £4bn, joint venture with Masdar. The first turbine was installed on 21 April 2026 and all foundations by August 2026; full operation is expected by the end of 2026. The register shows 1,200 MW plus 100 MW of TEC still at "Consents Approved".</li>
   <li><strong>East Anglia TWO</strong>: 963 MW (company figure), with a CfD from Allocation Round 6, due 2028/29. <strong>East Anglia ONE North</strong>: 860 MW on the register, awaiting consents.</li>
   <li><strong>Whitelee</strong> (East Renfrewshire): 305 MW plus a 206 MW extension on the register, the UK's largest onshore wind farm. <strong>Kilgallioch</strong>: 274 MW.</li>
   <li>Pipeline on the register includes <strong>Machair</strong> offshore wind (2,000 MW, SPT, 2033).</li>
   <li>SP Energy Networks is a co-owner of EGL1 and Western Link.</li>
  </ul>
  <p class="note">Cruachan pumped storage (440 MW, Argyll) is owned by Drax, not ScottishPower. Drax's Cruachan II expansion (up to 600 MW) was consented in July 2023.</p></div>
</div>
<div class="src">Sources: SSE FY26 preliminary results (RNS, 28 May 2026); Iberdrola / ScottishPower Renewables project pages; NESO TEC Register (16 Oct 2026); Drax press release.</div>`;},
policy:D=>{
 const t=D.tec.conn;const sum=(k)=>Object.values(t).reduce((s,o)=>s+(o[k]||0),0);
 return `
<p class="intro">DESNZ's <em>Digest of UK Energy Statistics</em> (DUKES) is the official annual record. It covers the whole UK and all generators, including those on the distribution network. NESO's series above covers GB and transmission-level output plus estimates for embedded wind and solar. The two therefore differ. For example, gas is 93.2 TWh in DUKES and 77.3 TWh in NESO's series for 2025, a gap that reflects the difference in coverage.</p>
<div class="grid2">
 <div class="card"><h3>DUKES 2026: UK electricity in 2025</h3>
  <table><thead><tr><th>Measure</th><th class="n">TWh</th><th class="n">Share of generation</th></tr></thead><tbody>
   <tr><td>Total generation</td><td class="n">293.6</td><td class="n">100%</td></tr>
   <tr><td>Renewables</td><td class="n">153.0</td><td class="n">52.1% (record)</td></tr>
   <tr><td>— Wind (offshore 52.0, onshore 34.4)</td><td class="n">86.4</td><td class="n">29.5%</td></tr>
   <tr><td>— Bioenergy</td><td class="n">41.0</td><td class="n">14.0%</td></tr>
   <tr><td>— Solar</td><td class="n">20.1</td><td class="n">6.9%</td></tr>
   <tr><td>— Hydro</td><td class="n">5.4</td><td class="n">1.8%</td></tr>
   <tr><td>Gas</td><td class="n">93.2</td><td class="n">31.8%</td></tr>
   <tr><td>Nuclear</td><td class="n">35.9</td><td class="n">12.2%</td></tr>
   <tr><td>Coal</td><td class="n">0.0</td><td class="n">0% (first full year)</td></tr>
   <tr><td>Net imports (imports 43.9, exports 14.2)</td><td class="n">29.7</td><td class="n">—</td></tr>
   <tr><td>Total demand</td><td class="n">323.0</td><td class="n">—</td></tr>
  </tbody></table>
  <p class="note">Low-carbon share 64.3%. Net imports from France were 21.9 TWh, Norway 9.0, Denmark 2.5 and Belgium 2.0. Bioenergy share is calculated here from the DUKES figures (41.0 ÷ 293.6).</p>
  <p class="note"><strong>Latest quarter (Energy Trends, Sept 2026, Q2 2026):</strong> renewables reached a record 55.8% of generation (38.3 TWh). Wind was 27.9%, gas 26.8% and solar 12.3%. Net imports were 7.6 TWh.</p></div>
 <div class="card"><h3>Clean Power 2030: targets and today</h3>
  <table><thead><tr><th>Technology</th><th class="n">UK installed, end-2025 (DUKES)</th><th class="n">2030 range, GB (Action Plan)</th></tr></thead><tbody>
   <tr><td>Offshore wind</td><td class="n">16.7 GW</td><td class="n">43–50 GW</td></tr>
   <tr><td>Onshore wind</td><td class="n">16.4 GW</td><td class="n">27–29 GW</td></tr>
   <tr><td>Solar</td><td class="n">21.9 GW</td><td class="n">45–47 GW</td></tr>
   <tr><td>Battery storage</td><td class="n">${fmtN(sum('Battery storage')/1000,1)} GW*</td><td class="n">23–27 GW</td></tr>
   <tr><td>Long-duration storage (incl. pumped hydro)</td><td class="n">2.9 GW</td><td class="n">4–6 GW</td></tr>
   <tr><td>Nuclear</td><td class="n">5.9 GW</td><td class="n">3–4 GW</td></tr>
   <tr><td>Unabated gas</td><td class="n">36.6 GW</td><td class="n">35 GW (kept for back-up)</td></tr>
   <tr><td>Low-carbon dispatchable</td><td class="n">—</td><td class="n">2–7 GW</td></tr>
   <tr><td>Interconnectors</td><td class="n">10.7 GW†</td><td class="n">12–14 GW</td></tr>
  </tbody></table>
  <p class="note">The target is for clean sources to produce at least 95% of GB generation in a typical weather year. NESO's advice (November 2024) set two pathways: 50 GW offshore wind with no new dispatchable plant, or 43 GW offshore plus 2.7 GW of new dispatchable plant. Investment needed is £40bn or more a year.<br>* Battery figure is transmission-connected TEC only (NESO register, Oct 2026); DUKES Table 5.12 excludes batteries. † NESO Interconnector Register, operating import capacity.</p></div>
</div>
<div class="src">Sources: DESNZ DUKES 2026 Chapter 5 and Tables 5.12 and 6.2 (30 July 2026); DESNZ Energy Trends (29 September 2026); DESNZ Clean Power 2030 Action Plan (December 2024, updated April 2025); NESO Clean Power 2030 advice (5 November 2024).</div>`;},
sources:`
<div class="grid2"><div>
<h3>Primary data used</h3>
<ul class="factlist">
 <li><strong>NESO Data Portal</strong> (api.neso.energy): Historic GB Generation Mix (half-hourly, 2009 to the present; the live panel queries this on page load); Historic Demand Data 2024–2026 (interconnector flows and SCOTTISH_TRANSFER); TEC Register (16 Oct 2026); Interconnector Register.</li>
 <li><strong>NESO publications</strong>: ETYS Scottish boundaries; Winter Outlook Early View 2026/27; Clean Power 2030 advice; BP3 balancing cost metrics.</li>
 <li><strong>DESNZ</strong>: DUKES 2026 Chapters 5 and 6; Energy Trends, September 2026; Clean Power 2030 Action Plan.</li>
 <li><strong>National Grid / SP Energy Networks / SSEN Transmission</strong>: EGL1 and EGL2 project updates; RIIO-T3 statements.</li>
 <li><strong>SSE plc</strong>: FY26 preliminary results. <strong>ScottishPower / Iberdrola</strong>: East Anglia project pages and CfD announcements.</li>
</ul></div><div>
<h3>Definitions and caveats</h3>
<ul class="factlist">
 <li><strong>TEC</strong> (Transmission Entry Capacity) is the contracted maximum export to the transmission system. It is not the same as nameplate or de-rated capacity.</li>
 <li>"Connected" in the TEC charts means rows with MW Connected above zero, de-duplicated by project and site. "Pipeline" means rows not marked Built that have a positive MW increase. Contracted dates are not delivery forecasts.</li>
 <li>The NESO generation mix converts half-hourly MW to energy (MWh = MW × 0.5). Its "Imports" is gross imports. Net imports are calculated from the per-link flows.</li>
 <li>Interconnector flow sign: positive means into GB. Moyle connects GB to Northern Ireland, which is part of the UK but not GB.</li>
 <li>Site locations on the map are approximate and for illustration only.</li>
 <li>The Alvarez &amp; Marsal colours and fonts used here are approximations. They come from a third-party template, not A&amp;M's own brand guidelines, and should be checked against the official brand kit before external use.</li>
</ul></div></div>`
});
