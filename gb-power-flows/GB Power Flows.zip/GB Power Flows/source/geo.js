const GEO={
icGeo:[
 {key:'IFA_FLOW',reg:'IFA Interconnector',name:'IFA',short:'IFA',cty:'France',cap:1988,gb:[51.106,0.98],far:[50.75,1.75],lab:[50.55,1.55],bend:10},
 {key:'IFA2_FLOW',reg:'IFA2 Interconnector',name:'IFA2',short:'IFA2',cty:'France',cap:1100,gb:[50.83,-1.28],far:[49.25,-0.25],lab:[49.35,-0.6],bend:0},
 {key:'ELECLINK_FLOW',reg:'ElecLink',name:'ElecLink',short:'ElecLink',cty:'France',cap:1000,gb:[51.09,1.10],far:[50.92,1.80],lab:[50.95,2.25],anchor:'start',bend:-6},
 {key:'NEMO_FLOW',reg:'Nemo Link',name:'Nemo Link',short:'Nemo',cty:'Belgium',cap:1020,gb:[51.30,1.35],far:[51.33,3.20],lab:[51.15,3.0],bend:0},
 {key:'BRITNED_FLOW',reg:'Britned',name:'BritNed',short:'BritNed',cty:'Netherlands',cap:1200,gb:[51.44,0.72],far:[51.96,4.00],lab:[52.2,3.8],bend:-8},
 {key:'VIKING_FLOW',reg:'Viking Link Denmark Interconnector',name:'Viking Link',short:'Viking',cty:'Denmark',cap:1500,gb:[52.93,-0.19],far:[55.52,8.60],lab:[55.15,7.2],bend:-20},
 {key:'NSL_FLOW',reg:'NS Link',name:'North Sea Link',short:'NSL',cty:'Norway',cap:1400,gb:[55.13,-1.51],far:[59.35,6.10],lab:[59.6,4.3],bend:-20},
 {key:'MOYLE_FLOW',reg:'Auchencrosh (interconnector CCT)',name:'Moyle',short:'Moyle',cty:'Northern Ireland',cap:500,gb:[55.07,-4.98],far:[54.84,-5.78],lab:[55.15,-6.6],bend:0},
 {key:'EAST_WEST_FLOW',reg:'East West Interconnector',name:'East West (EWIC)',short:'EWIC',cty:'Ireland',cap:505,gb:[53.22,-3.05],far:[53.47,-6.30],lab:[53.75,-6.6],bend:0},
 {key:'GREENLINK_FLOW',reg:'Greenlink',name:'Greenlink',short:'Greenlink',cty:'Ireland',cap:504,gb:[51.68,-4.99],far:[52.25,-6.90],lab:[52.0,-7.6],bend:0}
],
siteGeo:{
 'Drax Power Station':[53.736,-0.997],'Heysham Power Station':[54.029,-2.916],'Pembroke Power Station':[51.684,-4.990],'Staythorpe C':[53.073,-0.857],
 'Dinorwig':[53.119,-4.114],'Grain':[51.444,0.716],'Didcot B':[51.623,-1.267],"Connah's Quay":[53.231,-3.081],'South Humber Bank':[53.598,-0.141],
 'West Burton B':[53.360,-0.810],'Sofia Offshore Wind Farm':[54.95,1.95],'Immingham':[53.633,-0.235],'Torness':[55.968,-2.408],'Seabank':[51.539,-2.669],
 'Sizewell B':[52.214,1.620],'Dogger Bank Project 4 (Dogger Bank B)':[55.05,2.35],'Dogger Bank Project A':[54.78,1.75],'Hartlepool':[54.635,-1.181],
 'Peterhead':[57.478,-1.789],'Saltend':[53.737,-0.247],'Seagreen 1 Offshore Wind Farm':[56.60,-1.75],'Spalding':[52.810,-0.150],'Marchwood':[50.900,-1.430],
 'Carrington Power Station':[53.437,-2.410],'Keadby':[53.595,-0.743],'Langage':[50.390,-4.020],'Moray East Offshore Wind Farm':[58.19,-2.72],
 'Moray West Offshore Windfarm':[58.08,-3.10],'Severn Power':[51.548,-2.975],'Sutton Bridge':[52.760,0.190],'Triton Knoll Offshore Wind Farm':[53.50,0.80],
 'Damhead Creek':[51.424,0.600],'Rocksavage':[53.315,-2.720],'Coryton':[51.512,0.512],'Elmya Dalry BESS & PV':[55.71,-4.72],'Keadby South Power Station':[53.585,-0.735],
 'Little Barford':[52.200,-0.270],'Medway Power Station':[51.437,0.700],'Rye House':[51.763,0.010],'East Anglia One':[52.23,2.50],'Keadby II':[53.600,-0.750]
}};
