(function(){
const $=s=>document.querySelector(s);
const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const fmt=(v,d=0)=>Number(v).toLocaleString('en-GB',{maximumFractionDigits:d,minimumFractionDigits:d});
const tip=$('#tip');
function showTip(e,html){tip.innerHTML=html;tip.style.display='block';const w=tip.offsetWidth,h=tip.offsetHeight;let x=e.clientX+14,y=e.clientY+14;if(x+w>innerWidth-8)x=e.clientX-w-14;if(y+h>innerHeight-8)y=e.clientY-h-14;tip.style.left=Math.max(8,x)+'px';tip.style.top=Math.max(8,y)+'px';}
function hideTip(){tip.style.display='none';}
document.addEventListener('scroll',hideTip,{passive:true});

/* Theme */
const root=document.documentElement;
try{const t=localStorage.getItem('gbpf-theme');if(t)root.dataset.theme=t;}catch(e){}
$('#themeBtn').onclick=()=>{const dark=root.dataset.theme? root.dataset.theme==='dark' : matchMedia('(prefers-color-scheme: dark)').matches;root.dataset.theme=dark?'light':'dark';try{localStorage.setItem('gbpf-theme',root.dataset.theme)}catch(e){};renderAll();};

/* Fuel series: fixed order = palette slot order */
const FUELS=[
 {k:'wind',n:'Wind',c:'--s-wind',f:r=>(+r.WIND||0)+(+r.WIND_EMB||0)},
 {k:'gas',n:'Gas',c:'--s-gas',f:r=>+r.GAS||0},
 {k:'hydro',n:'Hydro, storage & other',c:'--s-hydro',f:r=>(+r.HYDRO||0)+(+r.STORAGE||0)+(+r.OTHER||0)},
 {k:'solar',n:'Solar',c:'--s-solar',f:r=>+r.SOLAR||0},
 {k:'imports',n:'Imports',c:'--s-imports',f:r=>+r.IMPORTS||0},
 {k:'biomass',n:'Biomass',c:'--s-biomass',f:r=>+r.BIOMASS||0},
 {k:'nuclear',n:'Nuclear',c:'--s-nuclear',f:r=>+r.NUCLEAR||0},
 {k:'coal',n:'Coal',c:'--s-coal',f:r=>+r.COAL||0}];
const legend=(el,items)=>{el.innerHTML=items.map(i=>`<span><i style="background:var(${i.c})"></i>${i.n}</span>`).join('');};

/* KPIs */
function kpis(){
  const a=DATA.annual['2025'];const wind=a.WIND+a.WIND_EMB;const g=a.GENERATION;
  const f=DATA.flows['2025'];let net=0;Object.keys(f).filter(k=>k.endsWith('_FLOW')).forEach(k=>net+=f[k].net);
  const K=[
    {v:fmt(g,0)+' TWh',l:'GB generation incl. imports, 2025',s:'NESO generation mix'},
    {v:fmt(wind/g*100,1)+'%',l:'Wind share, 2025',s:fmt(wind,1)+' TWh, largest single source'},
    {v:fmt(a.GAS/g*100,1)+'%',l:'Gas share, 2025',s:fmt(a.GAS,1)+' TWh'},
    {v:fmt(net,1)+' TWh',l:'Net imports, 2025',s:'Gross imports '+fmt(a.IMPORTS,1)+' TWh'},
    {v:a.CI+' g',l:'Average carbon intensity, 2025',s:'gCO₂/kWh · 445 g in 2009'},
    {v:fmt(DATA.tec.pipeTotal/1000,0)+' GW',l:'TEC pipeline not yet built',s:fmt(DATA.tec.pipeN,0)+' agreements · Oct 2026'}];
  $('#kpis').innerHTML=K.map(k=>`<div class="kpi"><div class="v">${k.v}</div><div class="l">${k.l}</div><div class="s">${k.s}</div></div>`).join('');
}

/* Generic helpers */
function svgFor(el,w,h){el.innerHTML='';return d3.select(el).append('svg').attr('viewBox',`0 0 ${w} ${h}`).attr('role','img');}
function W(el){return Math.max(300,Math.min(1100,el.clientWidth||600));}

/* Annual mix */
let mixUnit='twh';
function mixChart(){
  const el=$('#mixChart');const w=W(el),h=Math.round(Math.min(420,w*0.6));const m={t:10,r:8,b:28,l:44};
  const years=Object.keys(DATA.annual);
  const rows=years.map(y=>{const a=DATA.annual[y];const o={y:y==='2026'?'2026*':y,total:0};FUELS.forEach(F=>{o[F.k]=F.f(a);o.total+=o[F.k];});return o;});
  const vals=rows.map(r=>{const o={y:r.y,total:r.total};FUELS.forEach(F=>o[F.k]=mixUnit==='pct'?r[F.k]/r.total*100:r[F.k]);return o;});
  const svg=svgFor(el,w,h).attr('aria-label','Stacked columns of annual GB generation by fuel 2009 to 2026');
  const x=d3.scaleBand().domain(vals.map(d=>d.y)).range([m.l,w-m.r]).padding(.18);
  const ymax=mixUnit==='pct'?100:d3.max(vals,d=>d.total);
  const y=d3.scaleLinear().domain([0,ymax]).nice().range([h-m.b,m.t]);
  svg.append('g').attr('class','grid').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5).tickSize(-(w-m.l-m.r)).tickFormat(''));
  const st=d3.stack().keys(FUELS.map(F=>F.k))(vals);
  svg.append('g').selectAll('g').data(st).join('g').attr('fill',(d,i)=>css(FUELS[i].c)).selectAll('rect').data(d=>d).join('rect')
    .attr('x',d=>x(d.data.y)).attr('width',x.bandwidth()).attr('y',d=>y(d[1])).attr('height',d=>Math.max(0,y(d[0])-y(d[1])-(y(d[0])-y(d[1])>3?1.5:0)));
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(x.domain().filter((d,i)=>w>620||i%2===0)).tickSizeOuter(0));
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(d=>mixUnit==='pct'?d+'%':d)).call(g=>g.select('.domain').remove());
  svg.append('text').attr('x',m.l).attr('y',m.t-0).attr('dy','-0.2em').attr('fill',css('--muted')).attr('font-size',11).text(mixUnit==='pct'?'% of total':'TWh');
  svg.append('g').selectAll('rect').data(vals).join('rect').attr('x',d=>x(d.y)-x.step()*x.padding()/2).attr('width',x.step()).attr('y',m.t).attr('height',h-m.b-m.t).attr('fill','transparent')
   .on('mousemove',(e,d)=>showTip(e,`<b>${d.y==='2026*'?'2026 (to 20 Oct)':d.y}</b>`+FUELS.slice().reverse().map(F=>`<div class="row"><span><i style="background:var(${F.c})"></i>${F.n}</span><span>${mixUnit==='pct'?fmt(d[F.k],1)+'%':fmt(d[F.k],1)+' TWh'}</span></div>`).join('')+(mixUnit==='twh'?`<div class="row"><span>Total</span><span>${fmt(d.total,1)} TWh</span></div>`:'')))
   .on('mouseleave',hideTip);
  // table
  $('#mixTable').innerHTML='<table><thead><tr><th>Year</th>'+FUELS.map(F=>`<th class="n">${F.n}</th>`).join('')+'<th class="n">Total</th></tr></thead><tbody>'+rows.map(r=>`<tr><td>${r.y}</td>`+FUELS.map(F=>`<td class="n">${fmt(r[F.k],1)}</td>`).join('')+`<td class="n">${fmt(r.total,1)}</td></tr>`).join('')+'</tbody></table><p class="note">TWh. * 2026 to 20 October.</p>';
}
document.querySelectorAll('#mix .toggle button').forEach(b=>b.onclick=()=>{mixUnit=b.dataset.u;document.querySelectorAll('#mix .toggle button').forEach(x=>x.setAttribute('aria-pressed',x===b));mixChart();});

/* Live */
let LIVE=null;
async function loadLive(){
  try{
    const u='https://api.neso.energy/api/3/action/datastore_search?resource_id=f93d1835-75bc-43e5-84ad-12472b180a98&limit=96&sort=_id%20desc';
    const r=await fetch(u);const j=await r.json();LIVE=j.result.records.reverse();
  }catch(e){LIVE=null;}
  if(!LIVE||!LIVE.length){LIVE=CONTENT.liveFallback;$('#liveMeta').innerHTML='Live feed unavailable. Showing the stored half-hour of 20 Oct 2026 12:00.';}
  renderLive();
}
function renderLive(){
  if(!LIVE)return;
  const last=LIVE[LIVE.length-1];const tot=FUELS.reduce((s,F)=>s+F.f(last),0);
  const t=new Date(last.DATETIME+'Z');
  if(!$('#liveMeta').textContent.startsWith('Live feed unavailable'))
   $('#liveMeta').innerHTML=`<strong>${t.toLocaleString('en-GB',{timeZone:'Europe/London',weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</strong> (UK time) · total ${fmt(tot/1000,1)} GW · carbon intensity <strong>${last.CARBON_INTENSITY} gCO₂/kWh</strong>`;
  const el=$('#liveBars');const w=W(el),rowH=30,h=FUELS.length*rowH+10;const m={l:150,r:70};
  const data=FUELS.map(F=>({F,v:F.f(last)})).sort((a,b)=>b.v-a.v);
  const svg=svgFor(el,w,h).attr('aria-label','Current generation by fuel');
  const x=d3.scaleLinear().domain([0,d3.max(data,d=>d.v)||1]).range([m.l,w-m.r]);
  const g=svg.selectAll('g').data(data).join('g').attr('transform',(d,i)=>`translate(0,${i*rowH+6})`);
  g.append('text').attr('x',m.l-8).attr('y',rowH/2).attr('dy','.1em').attr('text-anchor','end').attr('fill',css('--text-2')).attr('font-size',13).text(d=>d.F.n);
  g.append('rect').attr('x',m.l).attr('y',rowH/2-8).attr('height',14).attr('rx',3).attr('width',d=>Math.max(2,x(d.v)-m.l)).attr('fill',d=>css(d.F.c));
  g.append('text').attr('x',d=>Math.max(m.l+2,x(d.v))+6).attr('y',rowH/2).attr('dy','.1em').attr('fill',css('--text')).attr('font-size',12).text(d=>fmt(d.v/1000,1)+' GW · '+fmt(d.v/tot*100,0)+'%');
  // 48h stacked area
  legend($('#liveLegend'),FUELS);
  const el2=$('#live48');const w2=W(el2),h2=240;const m2={t:8,r:8,b:24,l:36};
  const rows=LIVE.map(r=>{const o={t:new Date(r.DATETIME+'Z')};FUELS.forEach(F=>o[F.k]=F.f(r)/1000);return o;});
  const s2=svgFor(el2,w2,h2).attr('aria-label','Generation by fuel over the last 48 hours');
  const x2=d3.scaleTime().domain(d3.extent(rows,d=>d.t)).range([m2.l,w2-m2.r]);
  const st=d3.stack().keys(FUELS.map(F=>F.k))(rows);
  const y2=d3.scaleLinear().domain([0,d3.max(st[st.length-1],d=>d[1])]).nice().range([h2-m2.b,m2.t]);
  s2.append('g').attr('class','grid').attr('transform',`translate(${m2.l},0)`).call(d3.axisLeft(y2).ticks(4).tickSize(-(w2-m2.l-m2.r)).tickFormat(''));
  s2.append('g').selectAll('path').data(st).join('path').attr('fill',(d,i)=>css(FUELS[i].c)).attr('stroke',css('--surface')).attr('stroke-width',1).attr('d',d3.area().x(d=>x2(d.data.t)).y0(d=>y2(d[0])).y1(d=>y2(d[1])));
  s2.append('g').attr('class','axis').attr('transform',`translate(0,${h2-m2.b})`).call(d3.axisBottom(x2).ticks(w2>500?8:4).tickFormat(d3.timeFormat('%a %H:%M')));
  s2.append('g').attr('class','axis').attr('transform',`translate(${m2.l},0)`).call(d3.axisLeft(y2).ticks(4)).call(g=>g.select('.domain').remove());
  const cross=s2.append('line').attr('stroke',css('--text-2')).attr('y1',m2.t).attr('y2',h2-m2.b).style('display','none');
  s2.append('rect').attr('x',m2.l).attr('y',m2.t).attr('width',w2-m2.l-m2.r).attr('height',h2-m2.t-m2.b).attr('fill','transparent')
   .on('mousemove',e=>{const [px]=d3.pointer(e);const t=x2.invert(px);const i=d3.bisector(d=>d.t).center(rows,t);const d=rows[i];cross.attr('x1',x2(d.t)).attr('x2',x2(d.t)).style('display',null);
     showTip(e,`<b>${d.t.toLocaleString('en-GB',{timeZone:'Europe/London',weekday:'short',hour:'2-digit',minute:'2-digit'})}</b>`+FUELS.slice().reverse().map(F=>`<div class="row"><span><i style="background:var(${F.c})"></i>${F.n}</span><span>${fmt(d[F.k],1)} GW</span></div>`).join(''));})
   .on('mouseleave',()=>{cross.style('display','none');hideTip();});
}

/* Map */
let WORLD=null;const layers={sites:true,flows:true};
const TYPEC={'Gas & thermal':'--s-gas','Offshore wind':'--s-wind','Onshore wind':'--s-wind','Nuclear':'--s-nuclear','Biomass & waste':'--s-biomass','Pumped storage':'--s-hydro','Hydro':'--s-hydro','Battery storage':'--s-solar','Solar':'--s-solar','Other':'--s-coal'};
async function loadWorld(){try{WORLD=await (await fetch('https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-50m.json')).json();}catch(e){WORLD=null;}mapChart();}
function mapChart(){
  const el=$('#map');const w=W(el),h=Math.round(w*1.25);
  const svg=svgFor(el,w,h).attr('aria-label','Map of Great Britain with major power stations and electricity flows');
  const proj=d3.geoTransverseMercator().rotate([2,0]).fitExtent([[4,4],[w-4,h-4]],{type:'MultiPoint',coordinates:[[-8.6,49.8],[6.5,61.0],[-8.6,61.0],[6.5,49.8]]});
  const path=d3.geoPath(proj);
  if(WORLD){const fc=topojson.feature(WORLD,WORLD.objects.countries);
    const EU=new Set(['826','372','250','056','528','276','208','578','752','442','620','724']);
    svg.append('defs').append('clipPath').attr('id','mapclip').append('rect').attr('width',w).attr('height',h);
    svg.append('g').attr('clip-path','url(#mapclip)').selectAll('path').data(fc.features.filter(f=>EU.has(f.id))).join('path').attr('class',d=>'land'+(d.id==='826'?' gb':'')).attr('d',path);}
  else svg.append('text').attr('x',10).attr('y',20).attr('fill',css('--muted')).text('Base map unavailable offline');
  const defs=svg.append('defs');
  ['pos','neg','scot'].forEach(k=>defs.append('marker').attr('id','ar-'+k).attr('viewBox','0 0 10 10').attr('refX',7).attr('refY',5).attr('markerUnits','userSpaceOnUse').attr('markerWidth',9).attr('markerHeight',9).attr('orient','auto-start-reverse').append('path').attr('d','M0,0L10,5L0,10z').attr('fill',k==='scot'?css('--brand-2'):css('--'+k)));
  if(layers.flows){
    const g=svg.append('g');
    const f=DATA.flows['2025'];
    const ws=d3.scaleSqrt().domain([0,11]).range([1,3.5]);const wsS=d3.scaleSqrt().domain([0,11]).range([1.5,9]);
    CONTENT.icGeo.forEach(ic=>{
      const v=f[ic.key]?f[ic.key].net:0;const a=proj([ic.gb[1],ic.gb[0]]),b=proj([ic.far[1],ic.far[0]]);
      const imp=v>=0;const from=imp?b:a,to=imp?a:b;
      const mx=(from[0]+to[0])/2+(ic.bend||0),my=(from[1]+to[1])/2-(ic.bend||0)*.3;
      g.append('path').attr('d',`M${from[0]},${from[1]}Q${mx},${my} ${to[0]},${to[1]}`).attr('fill','none').attr('stroke',css(imp?'--pos':'--neg')).attr('stroke-width',ws(Math.abs(v))).attr('stroke-opacity',.85).attr('stroke-linecap','round').attr('marker-end',`url(#ar-${imp?'pos':'neg'})`)
        .on('mousemove',e=>showTip(e,`<b>${ic.name}</b>${ic.cty} · ${fmt(ic.cap,0)} MW import capacity<br>2025: imports ${fmt(f[ic.key].imp,2)} TWh, exports ${fmt(f[ic.key].exp,2)} TWh<br><strong>Net ${imp?'import':'export'} ${fmt(Math.abs(v),2)} TWh</strong>`)).on('mouseleave',hideTip);
      const lp=ic.lab?proj([ic.lab[1],ic.lab[0]]):b;
      g.append('text').attr('class','flowlabel').attr('x',lp[0]).attr('y',lp[1]).attr('text-anchor',ic.anchor||'middle').text(`${ic.short} ${imp?'+':'−'}${fmt(Math.abs(v),1)}`);
    });
    // Scotland-England
    const s=DATA.flows['2025'].SCOT;const a=proj([-3.0,56.2]),b=proj([-2.2,54.3]);
    g.append('path').attr('d',`M${a[0]},${a[1]}L${b[0]},${b[1]}`).attr('stroke',css('--brand-2')).attr('stroke-width',wsS(s.twh)).attr('stroke-opacity',.9).attr('marker-end','url(#ar-scot)').attr('fill','none')
      .on('mousemove',e=>showTip(e,`<b>Scotland → England transfer, 2025</b>${fmt(s.twh,1)} TWh net southward<br>Average ${fmt(s.avg,0)} MW · peak ${fmt(s.max,0)} MW<br>Northward at times (min ${fmt(s.min,0)} MW)`)).on('mouseleave',hideTip);
    const lp=proj([-1.2,55.4]);g.append('text').attr('class','flowlabel').attr('x',lp[0]).attr('y',lp[1]).text(`Scot→Eng ${fmt(s.twh,1)} TWh`);
  }
  if(layers.sites){
    const r=d3.scaleSqrt().domain([0,4000]).range([0,w/38]);
    const sites=DATA.tec.top.filter(t=>t.type!=='Offshore wind').map(t=>({...t,geo:CONTENT.siteGeo[t.name]})).filter(d=>d.geo).concat(DATA.offshore.map(f=>({...f,site:f.phases>1?f.phases+' TEC phases combined':'Offshore'}))).sort((a,b)=>b.mw-a.mw);
    svg.append('g').selectAll('circle').data(sites).join('circle').attr('class','sitecircle').attr('cx',d=>proj([d.geo[1],d.geo[0]])[0]).attr('cy',d=>proj([d.geo[1],d.geo[0]])[1]).attr('r',d=>Math.max(3,r(d.mw))).attr('fill',d=>css(TYPEC[d.type]||'--muted')).attr('fill-opacity',.85).attr('stroke-width',1.5)
     .on('mousemove',(e,d)=>showTip(e,`<b>${d.name}</b>${d.type} · ${fmt(d.mw,0)} MW TEC<br>${d.owner}<br><span class="note">${d.site} · ${d.to}</span>`)).on('mouseleave',hideTip);
  }
  const tl=[{n:'Gas',c:'--s-gas'},{n:'Wind',c:'--s-wind'},{n:'Nuclear',c:'--s-nuclear'},{n:'Biomass',c:'--s-biomass'},{n:'Hydro / pumped storage',c:'--s-hydro'},{n:'Battery',c:'--s-solar'}];
  $('#mapLegend').innerHTML=(layers.sites?tl.map(i=>`<span><i style="background:var(${i.c});border-radius:50%"></i>${i.n}</span>`).join(''):'')+(layers.flows?`<span><i style="background:var(--pos)"></i>Net import (TWh)</span><span><i style="background:var(--neg)"></i>Net export (TWh)</span><span><i style="background:var(--brand-2)"></i>Scotland→England</span>`:'');
}
document.querySelectorAll('#map-s .toggle button').forEach(b=>b.onclick=()=>{layers[b.dataset.l]=!layers[b.dataset.l];b.setAttribute('aria-pressed',layers[b.dataset.l]);mapChart();});
function offTable(){
  const o=DATA.offshore;$('#offTable').innerHTML=`<table><thead><tr><th>Wind farm</th><th>TO</th><th class="n">TEC MW</th></tr></thead><tbody>`+o.map(f=>`<tr><td>${f.name}${f.phases>1?` <span class="note">(${f.phases} phases)</span>`:''}</td><td>${f.to}</td><td class="n">${fmt(f.mw)}</td></tr>`).join('')+`<tr><td><strong>Total, ${o.length} farms</strong></td><td></td><td class="n"><strong>${fmt(o.reduce((s,f)=>s+f.mw,0))}</strong></td></tr></tbody></table>`;
}
function topTable(){
  $('#topTable').innerHTML='<table><thead><tr><th>Station</th><th>Type</th><th class="n">MW</th></tr></thead><tbody>'+DATA.tec.top.map(t=>`<tr><td>${t.name}<br><span class="note">${t.owner} · ${t.to}</span></td><td>${t.type}</td><td class="n">${fmt(t.mw)}</td></tr>`).join('')+'</tbody></table>';
}

/* Interconnectors */
function icChart(){
  const f=DATA.flows['2025'];
  const el=$('#icChart');const w=W(el);const narrow=w<520;
  const data=CONTENT.icGeo.map(ic=>({n:narrow?ic.short+' ('+ic.cty.replace('Northern Ireland','NI')+')':ic.name+' ('+ic.cty+')',v:f[ic.key].net,ic})).sort((a,b)=>b.v-a.v);
  const _w=w,rowH=28,h=data.length*rowH+30;const m={l:narrow?118:190,r:40};
  const svg=svgFor(el,w,h).attr('aria-label','Net interconnector flows 2025');
  const x=d3.scaleLinear().domain([d3.min(data,d=>d.v)-1.4,d3.max(data,d=>d.v)+0.5]).range([m.l,w-m.r]);
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-22})`).call(d3.axisBottom(x).ticks(5));
  svg.append('line').attr('x1',x(0)).attr('x2',x(0)).attr('y1',0).attr('y2',h-22).attr('stroke',css('--muted'));
  const g=svg.selectAll('g.r').data(data).join('g').attr('class','r').attr('transform',(d,i)=>`translate(0,${i*rowH})`);
  g.append('text').attr('x',m.l-8).attr('y',rowH/2+4).attr('text-anchor','end').attr('font-size',12).attr('fill',css('--text-2')).text(d=>d.n);
  g.append('rect').attr('x',d=>x(Math.min(0,d.v))).attr('width',d=>Math.abs(x(d.v)-x(0))).attr('y',rowH/2-7).attr('height',14).attr('rx',3).attr('fill',d=>css(d.v>=0?'--pos':'--neg'));
  g.append('text').attr('x',d=>d.v>=0?x(d.v)+5:x(d.v)-5).attr('text-anchor',d=>d.v>=0?'start':'end').attr('y',rowH/2+4).attr('font-size',12).attr('fill',css('--text')).text(d=>(d.v>=0?'+':'−')+fmt(Math.abs(d.v),1));
  g.append('rect').attr('x',0).attr('width',w).attr('height',rowH).attr('fill','transparent').on('mousemove',(e,d)=>showTip(e,`<b>${d.n}</b>Imports ${fmt(f[d.ic.key].imp,2)} TWh · exports ${fmt(f[d.ic.key].exp,2)} TWh<br>Max import ${fmt(f[d.ic.key].maxImp)} MW · max export ${fmt(-f[d.ic.key].maxExp)} MW`)).on('mouseleave',hideTip);
}
function icTable(){
  const f25=DATA.flows['2025'],f26=DATA.flows['2026'];const byName={};CONTENT.icGeo.forEach(i=>byName[i.reg]=i);
  const seen=new Set();const rows=DATA.ic.slice().reverse().filter(r=>{if(seen.has(r.name))return false;seen.add(r.name);return true;}).sort((a,b)=>(a.status==='Built'?0:1)-(b.status==='Built'?0:1)||(a.date||'').localeCompare(b.date||''));
  $('#icTable').innerHTML='<table><thead><tr><th>Project</th><th>Status</th><th>GB connection</th><th class="n">Import MW</th><th class="n">Export MW</th><th>From</th><th class="n">2025 net TWh</th><th class="n">2026 YTD net</th></tr></thead><tbody>'+rows.map((r,i)=>{const g=byName[r.name];const brk=(r.status!=='Built'&&i>0&&rows[i-1].status==='Built')?'<tr><td colspan="8" style="background:var(--surface-2);font-weight:600">Pipeline (not yet operating)</td></tr>':'';return brk+(`<tr><td>${r.name}<br><span class="note">${r.owner}</span></td><td><span class="pill">${r.status}</span></td><td>${r.site} (${r.to})</td><td class="n">${fmt(r.imp)}</td><td class="n">${fmt(r.exp)}</td><td>${r.status==='Built'?'Operating':(r.date||'')}</td><td class="n">${g?fmt(f25[g.key].net,2):''}</td><td class="n">${g?fmt(f26[g.key].net,2):''}</td></tr>`)}).join('')+'</tbody></table><p class="note">Positive = net import to GB. 2026 YTD = 1 Jan to 29 Sep 2026. Isle of Man link (74 MW, 132 kV) is not reported in the NESO flow series.</p>';
}
function scotChart(){
  const mf=DATA.monthflows;const rows=Object.keys(mf).map(k=>({k,d:new Date(k+'-15'),v:mf[k][0]}));
  const el=$('#scotChart');const w=W(el),h=240;const m={t:12,r:12,b:24,l:44};
  const svg=svgFor(el,w,h).attr('aria-label','Monthly average Scotland to England transfer');
  const x=d3.scaleTime().domain(d3.extent(rows,d=>d.d)).range([m.l,w-m.r]);
  const y=d3.scaleLinear().domain([0,d3.max(rows,d=>d.v)*1.1]).nice().range([h-m.b,m.t]);
  svg.append('g').attr('class','grid').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4).tickSize(-(w-m.l-m.r)).tickFormat(''));
  svg.append('path').datum(rows).attr('fill','none').attr('stroke',css('--brand-2')).attr('stroke-width',2).attr('d',d3.line().x(d=>x(d.d)).y(d=>y(d.v)));
  svg.append('g').selectAll('circle').data(rows).join('circle').attr('cx',d=>x(d.d)).attr('cy',d=>y(d.v)).attr('r',4).attr('fill',css('--brand-2')).attr('stroke',css('--surface')).attr('stroke-width',2)
    .on('mousemove',(e,d)=>showTip(e,`<b>${d.d.toLocaleString('en-GB',{month:'long',year:'numeric'})}</b>Average ${fmt(d.v)} MW southward`)).on('mouseleave',hideTip);
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(w>500?10:5).tickFormat(d3.timeFormat('%b %y')));
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4)).call(g=>g.select('.domain').remove());
  const s=DATA.flows;
  $('#scotNote').innerHTML=`2025: ${fmt(s['2025'].SCOT.twh,1)} TWh net southward, average ${fmt(s['2025'].SCOT.avg)} MW, half-hourly peak ${fmt(s['2025'].SCOT.max)} MW. Transfer exceeded 5 GW in ${fmt(s['2025'].SCOT.p_gt5,1)}% of half-hours. 2026 to 29 Sept: ${fmt(s['2026'].SCOT.twh,1)} TWh, average ${fmt(s['2026'].SCOT.avg)} MW, peak ${fmt(s['2026'].SCOT.max)} MW.`;
}

/* TEC */
const TECCATS=[{n:'Battery storage',c:'--s-solar'},{n:'Solar',c:'--s-hydro'},{n:'Offshore wind',c:'--s-wind'},{n:'Onshore wind',c:'--s-imports'},{n:'Gas & thermal',c:'--s-gas'},{n:'Nuclear',c:'--s-nuclear'},{n:'Pumped storage',c:'--s-biomass'},{n:'Other',c:'--s-coal',lab:'Other (incl. biomass, hydro)'}];
const tecCat=k=>TECCATS.find(c=>c.n===k)?k:'Other';
const STATUSES=['Under Construction/Commissioning','Consents Approved','Awaiting Consents','Scoping'];
function tecIntro(){
  const t=DATA.tec;const g=t.pipeGate;
  $('#tecIntro').innerHTML=`The register lists every agreement to connect directly to the transmission network, plus large embedded projects. At 16 October 2026 it held <strong>${fmt(t.connTotal/1000,1)} GW</strong> of connected TEC across ${t.connN} sites and <strong>${fmt(t.pipeTotal/1000,0)} GW</strong> of contracted capacity not yet built — about seven times the connected total. Under the Connections Reform ("Gate 2 to whole queue") process, ${fmt(g['2']/1000,1)} GW has been classified Gate 2 (firm connection date) and ${fmt(g['1']/1000,0)} GW Gate 1 (indicative only); ${fmt(g['Not yet classified']/1000,0)} GW is not yet classified in the published register.`;
}
function toChart(){
  const c=DATA.tec.conn;const tos=['NGET','SHET','SPT','OFTO'];
  const cats=['Gas & thermal','Offshore wind','Onshore wind','Nuclear','Biomass & waste','Battery storage','Pumped storage','Hydro','Other','Solar'];
  const CC={'Gas & thermal':'--s-gas','Offshore wind':'--s-wind','Onshore wind':'--s-hydro','Nuclear':'--s-nuclear','Biomass & waste':'--s-biomass','Battery storage':'--s-solar','Pumped storage':'--s-imports','Hydro':'--s-imports','Other':'--s-coal','Solar':'--s-solar'};
  const LC=[{n:'Gas & thermal',c:'--s-gas'},{n:'Offshore wind',c:'--s-wind'},{n:'Onshore wind',c:'--s-hydro'},{n:'Nuclear',c:'--s-nuclear'},{n:'Biomass',c:'--s-biomass'},{n:'Battery & solar',c:'--s-solar'},{n:'Hydro & pumped storage',c:'--s-imports'},{n:'Other',c:'--s-coal'}];
  legend($('#toLegend'),LC);
  const rows=tos.map(t=>{const o={t};cats.forEach(k=>o[k]=(c[t]||{})[k]||0);o.total=cats.reduce((s,k)=>s+o[k],0);return o;});
  const el=$('#toChart');const w=W(el),rowH=40,h=rows.length*rowH+28;const m={l:50,r:60};
  const svg=svgFor(el,w,h);const x=d3.scaleLinear().domain([0,d3.max(rows,d=>d.total)]).range([m.l,w-m.r]);
  const st=d3.stack().keys(cats)(rows);
  svg.append('g').selectAll('g').data(st).join('g').attr('fill',d=>css(CC[d.key])).selectAll('rect').data(d=>d.map(v=>({v,key:d.key}))).join('rect')
   .attr('y',(d,i)=>i*rowH+8).attr('height',22).attr('x',d=>x(d.v[0])).attr('width',d=>Math.max(0,x(d.v[1])-x(d.v[0])-1))
   .on('mousemove',(e,d)=>showTip(e,`<b>${d.v.data.t} · ${d.key}</b>${fmt(d.v[1]-d.v[0])} MW`)).on('mouseleave',hideTip);
  svg.selectAll('text.l').data(rows).join('text').attr('x',m.l-6).attr('y',(d,i)=>i*rowH+23).attr('text-anchor','end').attr('font-size',13).attr('fill',css('--text-2')).text(d=>d.t);
  svg.selectAll('text.v').data(rows).join('text').attr('x',d=>x(d.total)+5).attr('y',(d,i)=>i*rowH+23).attr('font-size',12).attr('fill',css('--text')).text(d=>fmt(d.total/1000,1)+' GW');
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-22})`).call(d3.axisBottom(x).ticks(4).tickFormat(d=>d/1000+' GW'));
}
function pipeChart(){
  const pc=DATA.tec.pipeCat;const agg={};Object.keys(pc).forEach(k=>{const c=tecCat(k);agg[c]=agg[c]||{};STATUSES.forEach(s=>agg[c][s]=(agg[c][s]||0)+(pc[k][s]||0));});
  const rows=TECCATS.map(c=>({n:c.n,...agg[c.n]})).map(r=>{r.total=STATUSES.reduce((s,k)=>s+(r[k]||0),0);return r;});
  const SC=['--brand','--brand-2','--accent','--line'];const SN=['Under construction / commissioning','Consents approved','Awaiting consents','Scoping'];
  $('#pipeLegend').innerHTML=SN.map((n,i)=>`<span><i style="background:var(${SC[i]})"></i>${n}</span>`).join('');
  const el=$('#pipeChart');const w=W(el),rowH=32,h=rows.length*rowH+28;const m={l:120,r:56};
  const svg=svgFor(el,w,h);const x=d3.scaleLinear().domain([0,d3.max(rows,d=>d.total)]).range([m.l,w-m.r]);
  const st=d3.stack().keys(STATUSES).value((d,k)=>d[k]||0)(rows);
  svg.append('g').selectAll('g').data(st).join('g').attr('fill',(d,i)=>css(SC[i])).selectAll('rect').data(d=>d.map(v=>({v,key:d.key}))).join('rect')
   .attr('y',(d,i)=>i*rowH+6).attr('height',20).attr('x',d=>x(d.v[0])).attr('width',d=>Math.max(0,x(d.v[1])-x(d.v[0])-(x(d.v[1])-x(d.v[0])>3?1.5:0)))
   .on('mousemove',(e,d)=>showTip(e,`<b>${d.v.data.n}</b>${d.key}: ${fmt((d.v[1]-d.v[0])/1000,1)} GW<br>Total pipeline ${fmt(d.v.data.total/1000,1)} GW`)).on('mouseleave',hideTip);
  svg.selectAll('text.l').data(rows).join('text').attr('x',m.l-6).attr('y',(d,i)=>i*rowH+20).attr('text-anchor','end').attr('font-size',12).attr('fill',css('--text-2')).text(d=>d.n);
  svg.selectAll('text.v').data(rows).join('text').attr('x',d=>x(d.total)+5).attr('y',(d,i)=>i*rowH+20).attr('font-size',12).attr('fill',css('--text')).text(d=>fmt(d.total/1000,0)+' GW');
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-22})`).call(d3.axisBottom(x).ticks(4).tickFormat(d=>d/1000+' GW'));
}
function yearChart(){
  const py=DATA.tec.pipeYear;const years=Object.keys(py).filter(y=>y&&y!=='').sort((p,q)=>p==='≤2026'?-1:q==='≤2026'?1:p.localeCompare(q));
  const rows=years.map(y=>{const o={y};TECCATS.forEach(c=>o[c.n]=0);Object.keys(py[y]).forEach(k=>o[tecCat(k)]+=py[y][k]/1000);o.total=TECCATS.reduce((s,c)=>s+o[c.n],0);return o;});
  const el=$('#yearChart');const w=W(el),h=260;const m={t:10,r:8,b:26,l:36};
  const svg=svgFor(el,w,h);const x=d3.scaleBand().domain(years).range([m.l,w-m.r]).padding(.2);
  const y=d3.scaleLinear().domain([0,d3.max(rows,d=>d.total)]).nice().range([h-m.b,m.t]);
  svg.append('g').attr('class','grid').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4).tickSize(-(w-m.l-m.r)).tickFormat(''));
  const st=d3.stack().keys(TECCATS.map(c=>c.n))(rows);
  svg.append('g').selectAll('g').data(st).join('g').attr('fill',(d,i)=>css(TECCATS[i].c)).selectAll('rect').data(d=>d).join('rect').attr('x',d=>x(d.data.y)).attr('width',x.bandwidth()).attr('y',d=>y(d[1])).attr('height',d=>Math.max(0,y(d[0])-y(d[1])-(y(d[0])-y(d[1])>3?1.5:0)));
  svg.append('g').selectAll('rect').data(rows).join('rect').attr('x',d=>x(d.y)).attr('width',x.bandwidth()).attr('y',m.t).attr('height',h-m.b-m.t).attr('fill','transparent')
   .on('mousemove',(e,d)=>showTip(e,`<b>${d.y}</b>`+TECCATS.slice().reverse().filter(c=>d[c.n]>0.05).map(c=>`<div class="row"><span><i style="background:var(${c.c})"></i>${c.n}</span><span>${fmt(d[c.n],1)} GW</span></div>`).join('')+`<div class="row"><span>Total</span><span>${fmt(d.total,1)} GW</span></div>`)).on('mouseleave',hideTip);
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(years.filter((d,i)=>w>560||i%2===0)).tickFormat(d=>d.replace('20',"'")));
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4)).call(g=>g.select('.domain').remove());
  const lg=document.createElement('div');lg.className='legend';el.prepend(lg);legend(lg,TECCATS);
}
function ucTable(){
  $('#ucTable').innerHTML='<table><thead><tr><th>Project</th><th>Type</th><th class="n">MW</th><th>TEC date</th></tr></thead><tbody>'+DATA.tec.uc.map(u=>`<tr><td>${u.name}<br><span class="note">${u.site} · ${u.to}</span></td><td>${u.type}</td><td class="n">${fmt(u.mw)}</td><td>${u.date||''}</td></tr>`).join('')+'</tbody></table><p class="note">Status as recorded on the register. Some dates are already past; the register records the contracted date until it is formally changed.</p>';
}

/* Static content blocks */
function blocks(){
  $('#netContent').innerHTML=CONTENT.networks;
  $('#utilContent').innerHTML=CONTENT.utilities(DATA);
  $('#policyContent').innerHTML=CONTENT.policy(DATA);
  $('#sourcesContent').innerHTML=CONTENT.sources;
}

function renderAll(){legend($('#mixLegend'),FUELS);mixChart();renderLive();mapChart();icChart();scotChart();toChart();pipeChart();yearChart();}
kpis();topTable();offTable();icTable();tecIntro();ucTable();blocks();renderAll();loadLive();loadWorld();
let rt;addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(renderAll,200);});
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',renderAll);
})();
