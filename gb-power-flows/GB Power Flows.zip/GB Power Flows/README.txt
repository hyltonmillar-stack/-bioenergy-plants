GB POWER FLOWS - A&M INFRA Economics Market Intelligence
Compiled 20 October 2026

OPEN
  index.html  Full report: live mix, generation trend 2009-2026, map, interconnector
              and Scotland-England flows, TEC register pipeline, networks, SSE and
              ScottishPower, DESNZ statistics and Clean Power 2030 targets.
  map.html    Single-screen map: all 35 transmission-connected offshore wind farms,
              largest other stations, interconnector and Scotland-England flows.
  Keep both files in the same folder (index.html links to map.html).
  An internet connection is needed for the chart library, base map and live NESO feed.

DATA (data/)
  tec_register_2026-10-16.json             NESO TEC Register extract (2,226 rows)
  interconnector_register_2026-10-16.json  NESO Interconnector Register extract
  neso_aggregates.json                     Annual/monthly mix and flow aggregates
  sitedata.json                            Data embedded in the pages

SOURCES
  NESO Data Portal (api.neso.energy): Historic GB Generation Mix; Historic Demand
  Data 2024-2026; TEC Register; Interconnector Register. NESO ETYS, Winter Outlook
  Early View 2026/27, Clean Power 2030 advice, BP3 cost metrics.
  DESNZ: DUKES 2026 Ch.5 and Tables 5.12, 6.2; Energy Trends Sept 2026; Clean Power
  2030 Action Plan. National Grid / SPEN / SSEN Transmission project updates and
  RIIO-T3 statements. SSE FY26 preliminary results. ScottishPower / Iberdrola.

CAVEATS
  - A&M colours (#00244a, #0085ca, #cf7f00) and fonts (Barlow Condensed, Inter) are
    approximations from a third-party template. Check against the official brand kit
    before external use.
  - NESO (GB, transmission plus embedded wind/solar) and DESNZ DUKES (UK, all
    generators) measure generation differently; figures are labelled by source.
  - TEC is contracted export capacity, not nameplate capacity. Site locations are
    approximate.

REBUILD (source/)
  Python scripts in source/scripts pull NESO data and assemble the pages from
  template.html / map_template.html, app.js, content.js and geo.js.
